<!DOCTYPE html>
<html lang="en">

<head>
  <title>Kencana Energy</title>
  <link rel="icon" type="image/x-icon" href="foto/logo.png">
  <meta charset="utf-8">
  <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
  <link href="https://fonts.googleapis.com/css2?family=Spectral:ital,wght@0,200;0,300;0,400;0,500;0,700;0,800;1,200;1,300;1,400;1,500;1,700&display=swap" rel="stylesheet">
  <link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/font-awesome/4.7.0/css/font-awesome.min.css">
  <link rel="stylesheet" href="home/css/animate.css">
  <link rel="stylesheet" href="home/css/owl.carousel.min.css">
  <link rel="stylesheet" href="home/css/owl.theme.default.min.css">
  <link rel="stylesheet" href="home/css/magnific-popup.css">
  <link rel="stylesheet" href="home/css/flaticon.css">
  <link rel="stylesheet" href="home/css/style.css">
  <link rel="stylesheet" href="https://netdna.bootstrapcdn.com/font-awesome/4.0.3/css/font-awesome.css">
</head>
<nav class="navbar navbar-expand-lg navbar-dark ftco_navbar bg-dark ftco-navbar-light" id="ftco-navbar">
  <div class="container">
    <a class="navbar-brand" href="index.php"> <img src="foto/logo.png" width="150px" style="border-radius: 10px;"></a>
    <button class="navbar-toggler" type="button" data-toggle="collapse" data-target="#ftco-nav" aria-controls="ftco-nav" aria-expanded="false" aria-label="Toggle navigation">
      <i class="fa fa-list"></i>
    </button>

    <div class="collapse navbar-collapse" id="ftco-nav">
      <ul class="navbar-nav ml-auto">
        <?php
        if (isset($_SESSION['username'])) {
        ?>
          <li class="nav-item active"><a href="logout.php" class="nav-link">Logout</a></li>
        <?php } ?>
    </div>
  </div>
</nav>