<!-- Required vendors -->
<script src="assets/vendor/global/global.min.js"></script>
<script src="assets/js/quixnav-init.js"></script>
<script src="assets/js/custom.min.js"></script>


<!-- Vectormap -->
<script src="assets/vendor/raphael/raphael.min.js"></script>
<script src="assets/vendor/morris/morris.min.js"></script>


<script src="assets/vendor/circle-progress/circle-progress.min.js"></script>
<script src="assets/vendor/chart.js/Chart.bundle.min.js"></script>

<script src="assets/vendor/gaugeJS/dist/gauge.min.js"></script>

<!--  flot-chart js -->
<script src="assets/vendor/flot/jquery.flot.js"></script>
<script src="assets/vendor/flot/jquery.flot.resize.js"></script>

<!-- Owl Carousel -->
<script src="assets/vendor/owl-carousel/js/owl.carousel.min.js"></script>

<!-- Counter Up -->
<script src="assets/vendor/jqvmap/js/jquery.vmap.min.js"></script>
<script src="assets/vendor/jqvmap/js/jquery.vmap.usa.js"></script>
<script src="assets/vendor/jquery.counterup/jquery.counterup.min.js"></script>


<script src="assets/js/dashboard/dashboard-1.js"></script>

<script src="assets/vendor/datatables/js/jquery.dataTables.min.js"></script>
<script src="assets/js/plugins-init/datatables.init.js"></script>
<script>
    $(document).ready(function() {
        $('#tabel').DataTable();
    });
</script>
</body>

</html>